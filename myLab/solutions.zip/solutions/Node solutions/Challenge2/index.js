var {SearchService} = require('azure-search-client');

var client = new SearchService('<your-search-service>', '<API-KEY-HERE>');

async function printResult(result){
    var count=0;
    result.forEach(document => {
        console.log("Filename: " + document.file_name);
        console.log("URL: " + document.url);
        console.log("Size: " + document.size);
        console.log("Modified: " + document.last_modified);
        console.log('========================');
        count++;
    });
    console.log("count of documents: " + count);
}

async function NewYorkDocs() {
    console.log("Searching for New York Documents");
    const resp = await client.indexes.use('<your-index-name>').search({
        search: 'New York',
    });
    await printResult(resp.result.value)    
}

async function NewYorkDocsSortedByModifiedDate() {
    console.log("Searching for New York Documents sorting by last_modified");
    const resp = await client.indexes.use('<your-index-name>').search({
        search: 'New York',
        orderby: 'last_modified'
    });
    await printResult(resp.result.value)    
}

async function WildCardSearch() {
    console.log("Searching for Earls Court");
    const resp = await client.indexes.use('<your-index-name>').search({
        search: 'Earls Court'
    });
    await printResult(resp.result.value)    
}

async function MultipleSearchTerms() {
    console.log("Searching for London and Trafalgar Square");
    const resp = await client.indexes.use('<your-index-name>').search({
        search: "London AND \"Trafalgar Square\"",
        queryType: "full",
        searchMode: "all"
    });
    await printResult(resp.result.value)    
}

async function SearchReviews() {
    console.log("Searching for Reviews");
    const resp = await client.indexes.use('<your-index-name>').search({
        search: "reviews",
        searchFields: "url",
        queryType: "full"
    });
    await printResult(resp.result.value)    
}

async function SearchNotReviews() {
    console.log("Searching for Everything But Reviews");
    const resp = await client.indexes.use('<your-index-name>').search({
        search: "-reviews",
        searchFields: "url"
    });
    await printResult(resp.result.value)    
}

async function DubaiAndNotTheLostCity() {
    console.log("Searching for Dubai and not The Lost City");
    const resp = await client.indexes.use('<your-index-name>').search({
        search: "Dubai AND -\"The Lost City\"",
        searchMode: "all"
    });
    await printResult(resp.result.value)    
}

async function SanFranHotelsWithInternet() {
    console.log("Searching for SanFran Hotels with Internet (10 words)");
    const resp = await client.indexes.use('<your-index-name>').search({
        search: "\"San Francisco\" +\"hotel internet\"~10",
        queryType: "full"
    });
    await printResult(resp.result.value)
}

async function SanFranHotelsWithInternet() {
    console.log("Searching for SanFran Hotels with Internet (10 words)");
    const resp = await client.indexes.use('<your-index-name>').search({
        search: "\"San Francisco\" +\"hotel internet\"~10",
        queryType: "full"
    });
    await printResult(resp.result.value)
}

async function FuzzySearch() {
    console.log("Searching for fuzzy Josefine/a");
    const resp = await client.indexes.use('<your-index-name>').search({
        search: "josefine~2",
        queryType: "full"
    });
    await printResult(resp.result.value)
}

async function doWork(){
    await NewYorkDocs();
    await NewYorkDocsSortedByModifiedDate();
    await WildCardSearch();
    await MultipleSearchTerms();
    await SearchReviews();
    await SearchNotReviews();
    await DubaiAndNotTheLostCity();
    await SanFranHotelsWithInternet();
    await FuzzySearch();
}

doWork();