﻿using System;
using System.Net;
using System.Threading;

namespace Challenge_2
{
    using Microsoft.Azure.Search;
    using Microsoft.Azure.Search.Models;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Spatial;
    using Microsoft.Rest.Azure;
    class Program
    {
        static void Main(string[] args)
        {
            // Connect to Search Service
            IConfigurationBuilder builder = new ConfigurationBuilder().AddJsonFile("appsettings.json");
            IConfigurationRoot configuration = builder.Build();


            //Uncomment it if you hate Postman
            //InitializeAzureSearchProgrammatically(configuration);

            ISearchIndexClient indexClientForQueries = CreateSearchIndexClient(configuration);

            Console.WriteLine("Running Queries");
            RunQueries(indexClientForQueries);
        }

        private static void InitializeAzureSearchProgrammatically(IConfigurationRoot configuration)
        {
            SearchServiceClient serviceClient = CreateSearchServiceClient(configuration);
            //Create index
            Console.WriteLine("{0}", "Creating index...\n");
            CreateIndex(serviceClient);

            // Create Datasource
            Console.WriteLine("{0}", "Creating Datasource...\n");
            CreateDataSource(serviceClient, configuration);

            //Create indexer
            Console.WriteLine("{0}", "Creating Indexer...\n");
            CreateIndexer(serviceClient);

            //Run Indexer
            Console.WriteLine("{0}", "Running Indexer...\n");
            RunIndexer(serviceClient);
        }

        private static SearchServiceClient CreateSearchServiceClient(IConfigurationRoot configuration)
        {
            string searchServiceName = configuration["SearchServiceName"];
            string adminApiKey = configuration["SearchServiceAdminApiKey"];

            SearchServiceClient serviceClient = new SearchServiceClient(searchServiceName, new SearchCredentials(adminApiKey));
            return serviceClient;
        }
        private static SearchIndexClient CreateSearchIndexClient(IConfigurationRoot configuration)
        {
            string searchServiceName = configuration["SearchServiceName"];
            string queryApiKey = configuration["SearchServiceQueryApiKey"];

            SearchIndexClient indexClient = new SearchIndexClient(searchServiceName, "website-index", new SearchCredentials(queryApiKey));
            return indexClient;
        }
        private static void CreateIndex(SearchServiceClient serviceClient)
        {
            var definition = new Index()
            {
                Name = "website-index",
                Fields = FieldBuilder.BuildForType<IndexData>(),
            };
            bool exists = serviceClient.Indexes.Exists(definition.Name);
            if (exists)
            {
                serviceClient.Indexes.Delete(definition.Name);
            }
            serviceClient.Indexes.Create(definition);
        }

        private static void CreateDataSource(SearchServiceClient serviceClient, IConfigurationRoot configuration)
        {
            string connectionstring = configuration["StorageConnectionString"];
            DataSource blobdatasource = DataSource.AzureBlobStorage(
                name: "websitedata",
                storageConnectionString: connectionstring, 
                containerName: "data"
            );

            serviceClient.DataSources.CreateOrUpdate(blobdatasource);           
        }

        private static void CreateIndexer(SearchServiceClient serviceClient){
            FieldMapping[] maps = new FieldMapping[4];
            maps[0] = new FieldMapping(
                        sourceFieldName: "metadata_storage_name",
                        targetFieldName: "file_name"
                    );
            maps[1] = new FieldMapping(
                        sourceFieldName: "metadata_storage_path",
                        targetFieldName: "url"
                    );
            maps[2] = new FieldMapping(
                        sourceFieldName: "metadata_storage_size",
                        targetFieldName: "size"
                    );
            maps[3] = new FieldMapping(
                        sourceFieldName: "metadata_storage_last_modified",
                        targetFieldName: "last_modified"
                    );
            Indexer sqlIndexer = new Indexer(
                name: "website-indexer",
                dataSourceName: "websitedata",
                targetIndexName: "website-index",
                fieldMappings: maps,
                schedule: new IndexingSchedule(TimeSpan.FromDays(1)));
            // Indexers contain metadata about how much they have already indexed
            // If we already ran the sample, the indexer will remember that it already
            // indexed the sample data and not run again
            // To avoid this, reset the indexer if it exists
            bool exists = serviceClient.Indexers.Exists("website-indexer");
            if (exists)
            {
                serviceClient.Indexers.Reset("website-indexer");
            }

            serviceClient.Indexers.CreateOrUpdate(sqlIndexer);
        }

        private static void RunIndexer(SearchServiceClient serviceClient){
            try
            {
                serviceClient.Indexers.Run("website-indexer");
            }
            catch (CloudException e) when (e.Response.StatusCode == (HttpStatusCode)429)
            {
                Console.WriteLine("Failed to run indexer: {0}", e.Response.Content);
            } 
            Console.WriteLine("Waiting for documents to be indexed...\n");
            Thread.Sleep(10000);
        }

        private static void RunQueries(ISearchIndexClient indexClient)
        {
            SearchParameters parameters;
            DocumentSearchResult<IndexData> results;

            //The number of matching documents (hits) for a submitted search term
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Count of Documents matching 'New York' as search term:");

            parameters =
                new SearchParameters()
                {
                    Select = new[] { "file_name", "url", "size", "last_modified","content" },
                    IncludeTotalResultCount=true,
                    SearchFields = new[] {"content"}
                };

            results = indexClient.Documents.Search<IndexData>("\"New York\"", parameters);
            long? count = results.Results.Count;

            Console.Write("Result cout: {0}",count);
            Console.WriteLine();

            //Details of matching documents based on the search term. For example, the file name, URL, size, and last modified date of all documents that include "New York".
            WriteDocuments(results);        

            //Sorted results. For example, details of "New York" documents with the most recently modified documents listed first.
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Sorted results of reviews of 'New York':\n\n");

            parameters =
                new SearchParameters()
                {
                    OrderBy = new[] { "last_modified desc" },
                    SearchFields = new[] { "content" },
                    Select = new[] { "file_name", "url", "size", "last_modified" }
                };

            results = indexClient.Documents.Search<IndexData>("\"New York\"", parameters);

            WriteDocuments(results);

            //Wildcard matches. For example, a search that returns documents containing the term "Earl's Court", Earls Court", or "Earl`s Court".
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Documents that match 'Earl's Court', 'Earls Court', or 'Earl`s Court' \n\n");

            parameters =
                new SearchParameters()
                {
                    Select = new[] { "file_name", "url", "size", "last_modified", "content" },
                    QueryType = QueryType.Full,
                    SearchFields = new[] { "content" }
                };

            results = indexClient.Documents.Search<IndexData>("Earl?s Court", parameters);

            WriteDocuments(results);

            //Documents that match based on multiple search terms - for example, details of all documents that include "London" and "Trafalgar Square"
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("The file name, URL, and content of all documents that include 'London' and 'Trafalgar Square' \n\n");

            parameters =
                new SearchParameters()
                {
                    Select = new[] { "file_name", "url", "size", "last_modified", "content" },
                    SearchFields = new[] { "file_name", "url", "content" },
                    SearchMode=SearchMode.All
                };

            results = indexClient.Documents.Search<IndexData>("\"London\"+\"Trafalgar Square\"", parameters);

            WriteDocuments(results);

            //Matching reviews based on a search term - for example, all reviews that contain the term "New York".
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Details of reviews matching 'New York':\n\n");

            parameters =
                new SearchParameters()
                {
                    Filter = "search.ismatch('reviews', 'url')",
                    Select = new[] { "file_name", "url", "size", "last_modified", "content" },
                    SearchFields = new[] { "content" }
                };

            results = indexClient.Documents.Search<IndexData>("New York", parameters);

            WriteDocuments(results);

            //Documents that are not reviews.
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Documents that are not reviews:\n\n");

            parameters =
                new SearchParameters()
                {
                    Filter = "not search.ismatch('reviews', 'url')",
                    Select = new[] { "file_name", "url", "size", "last_modified" }
                };

            results = indexClient.Documents.Search<IndexData>("*", parameters);

            WriteDocuments(results);

            //Documents in which specified terms are not present. For example, documents that include "Dubai" but not "The Lost City".
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("The content of all documents that include \"Dubai\" and but not \"The Lost City\".\n\n");
            
            parameters =
                new SearchParameters()
                {
                    Select = new[] { "file_name", "url", "size", "last_modified", "content" },
                    SearchFields = new[] { "content" },
                    SearchMode=SearchMode.All
                };

            results = indexClient.Documents.Search<IndexData>("\"Dubai\" -\"The Lost City\"", parameters);

            WriteDocuments(results);

            //Results filtered by date. For example, collateral that was last modified this year.
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("The file name, URL, and content of all collateral modified this year.\n\n");
            
            parameters =
                new SearchParameters()
                {
                    OrderBy = new[] {"last_modified desc"},
                    Filter = "last_modified ge 2019-01-01T00:00:00Z",
                    QueryType = QueryType.Full,
                    Select = new[] { "file_name", "url", "size", "last_modified" },
                    
                };

            results = indexClient.Documents.Search<IndexData>("url:collateral", parameters);

            WriteDocuments(results);

            //Documents in which terms appear close to one another. For example, documents that include "San Franscisco", with the terms "hotel" and "Internet" within ten words of one another.
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("The file name, URL, and content of all documents that include \"San Franscisco\", and the terms \"hotel\" and \"Internet\" within ten words of one another.\n\n");
            
            parameters =
                new SearchParameters()
                {
                    Select = new[] { "file_name", "url", "size", "last_modified", "content" },
                    QueryType = QueryType.Full,
                    SearchMode = SearchMode.All
                };

            results = indexClient.Documents.Search<IndexData>("\"San Francisco\" + \"hotel\"~10 +\"Internet\"~10", parameters);

            WriteDocuments(results);


            //Documents that match fuzzy search terms. For example, a search for reviews containing "Josefine" should also return reviews containing "Josefina".
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Fuzzy search for 'Josefine' related reviews.\n\n");
            
            parameters =
                new SearchParameters()
                {
                    Select = new[] { "file_name", "url", "size", "last_modified", "content" },
                    Filter = "search.ismatch('reviews', 'url')",
                    SearchMode = SearchMode.All,
                    QueryType = QueryType.Full
                };

            results = indexClient.Documents.Search<IndexData>("Josefine~", parameters);

            WriteDocuments(results);

        }

        private static void WriteDocuments(DocumentSearchResult<IndexData> searchResults)
        {
            foreach (SearchResult<IndexData> result in searchResults.Results)
            {
                Console.WriteLine("---");
                Console.WriteLine("File Name {0}", result.Document.File_name);
                Console.WriteLine("File Path {0}", result.Document.Url); 
                if(result.Document.Size != 0)
                    Console.WriteLine("File Size {0}", result.Document.Size);
                if(result.Document.Last_modified != new DateTime(0001, 1, 1, 0, 0, 0))
                    Console.WriteLine("Last Modified {0}", result.Document.Last_modified);
                if(result.Document.Content != null)
                    Console.WriteLine("Content {0}", result.Document.Content);
            }

            Console.WriteLine();
        }
    }
}
