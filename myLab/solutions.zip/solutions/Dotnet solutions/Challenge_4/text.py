import json
# Define the request body
body = {
    "fields": [
        {
            # Unique ID for each document
            "name": "id",
            "type": "Edm.String",
            "key": True,
            "searchable": True,
            "filterable": True,
            "facetable": False,
            "sortable": True
        },
        {
            # The file path of the document
            "name": "url",
            "type": "Edm.String",
            "sortable": True,
            "searchable": True,
            "filterable": True,
            "facetable": False
        },
        {
            # The file name of the document
            "name": "file_name",
            "type": "Edm.String",
            "sortable": True,
            "searchable": True,
            "filterable": True,
            "facetable": False
        },
        {
            # The size of the document
            "name": "size",
            "type": "Edm.Int64",
            "sortable": True,
            "searchable": False,
            "filterable": True,
            "facetable": False
        },
        {
            # The last-modified date of the document
            "name": "last_modified",
            "type": "Edm.DateTimeOffset",
            "sortable": True,
            "searchable": False,
            "filterable": True,
            "facetable": False
        },
        {
            # The text content in the document
            "name": "content",
            "type": "Edm.String",
            "sortable": False,
            "searchable": True,
            "filterable": True,
            "facetable": False
        },
        {
            # The sentiment score
            "name": "sentiment",
            "type": "Edm.Double",
            "searchable": False,
            "sortable": True,
            "filterable": True,
            "facetable": True
        },
        {
            # Key phrases that might help identify the subject of the text
            "name": "key_phrases",
            "type": "Collection(Edm.String)",
            "searchable": True,
            "filterable": False,
            "facetable": False
        },
        {
            # Geographical locations mentioned in the text
            "name": "locations",
            "type": "Collection(Edm.String)",
            "searchable": True,
            "sortable": False,
            "filterable": True,
            "facetable": False
        },
        {
            # People mentioned in the text
            "name": "people",
            "type": "Collection(Edm.String)",
            "searchable": True,
            "sortable": False,
            "filterable": True,
            "facetable": False
        },
        {
            # URLs mentioned in the text
            "name": "links",
            "type": "Collection(Edm.String)",
            "searchable": True,
            "sortable": False,
            "filterable": True,
            "facetable": False
        },
        {
            # URLs mentioned in the text
            "name": "entities",
            "type": "Collection(Edm.String)",
            "searchable": True,
            "sortable": False,
            "filterable": True,
            "facetable": False
        },
        {
            # The image content in the document
            "name": "image_descriptions",
            "type": "Collection(Edm.String)",
            "sortable": False,
            "searchable": True,
            "filterable": True,
            "facetable": False
        },
        {
            # The text contained in images in the document
            "name": "image_text",
            "type": "Collection(Edm.String)",
            "searchable": True,
            "sortable": False,
            "filterable": True,
            "facetable": False
        },
        {
            # The combined source text plus the text extracted from images
            "name": "merged_text",
            "type": "Edm.String",
            "searchable": True,
            "sortable": False,
            "filterable": False,
            "facetable": False
        }
    ]
}
try:
    result = azsearch_rest(
        request_type="PUT", function_name="indexes/website-docs-index", body=json.dumps(body))
    if result != None:
        print(json.dumps(result, sort_keys=True, indent=2))
except Exception as e:
    print('Error:')
print(e)


body = {"description": "Extract and enhance text",  "skills":  [
    # Extract text from images (including those embedded in documents)
    {
        "description": "Extract descriptions from images.",
        "@odata.type": "#Microsoft.Skills.Vision.ImageAnalysisSkill",
        "context": "/document/normalized_images/*",
        "defaultLanguageCode": "en",
        "visualFeatures": ["Description"],
        "details": ["Landmarks"],
        "inputs": [{
            "name": "image",
            "source": "/document/normalized_images/*"
                }],
        "outputs": [{
            "name": "description",
            "targetName": "imageDescription"
            }]
    },
    # Extract text from images (including those embedded in documents)
    {"description": "Extract text from images.",            
    "@odata.type": "#Microsoft.Skills.Vision.OcrSkill",            
    "context": "/document/normalized_images/*",            
    "defaultLanguageCode": "en",
        "detectOrientation": True,            
        "inputs": [{
            "name": "image",                
            "source": "/document/normalized_images/*"}],            
        "outputs": [{
            "name": "text"}]},
    # Merge the extracted image text back into the content at the appropriate locations
    {"@odata.type": "#Microsoft.Skills.Text.MergeSkill",          "description": "Create merged_text, which includes all the textual representation of each image inserted at the right location in the content field.",          "context": "/document",          "insertPreTag": "[",          "insertPostTag": "]",          "inputs": [
        {"name": "text", "source": "/document/content"},            {"name": "itemsToInsert", "source": "/document/normalized_images/*/text"},            {"name": "offsets", "source": "/document/normalized_images/*/contentOffset"}],          "outputs": [{"name": "mergedText"}]},
    # Detect the sentiment
    {"description": "Detect sentiment.",          "@odata.type": "#Microsoft.Skills.Text.SentimentSkill",        "defaultLanguageCode": "en",          "inputs": [
        {"name": "text",              "source": "/document/mergedText"}],            "outputs": [{"name": "score",                  "targetName": "sentimentScore"}]},
    # Extract entities
    {"@odata.type": "#Microsoft.Skills.Text.EntityRecognitionSkill",          "categories": ["Organization", "location", "person", "datetime", "url"],          "defaultLanguageCode": "en",          "inputs": [
        {"name": "text",              "source": "/document/mergedText"}],          "outputs": [{"name": "locations"},            {"name": "persons"},            {"name": "urls"},            {"name": "entities"}]},
    # Extract key phrases from the pages
    {"@odata.type": "#Microsoft.Skills.Text.KeyPhraseExtractionSkill",          "context": "/document",          "defaultLanguageCode": "en",          "maxKeyPhraseCount": 5,          "inputs": [{"name": "text", "source": "/document/mergedText"}],          "outputs": [{"name": "keyPhrases"}]}, ],      "cognitiveServices": {"@odata.type": "#Microsoft.Azure.Search.CognitiveServicesByKey",        "description": "margies-cog-svc",        "key": cog_svc_key}}
   try:
        result = azsearch_rest(
            request_type="PUT", function_name="/skillsets/website-skillset", body=json.dumps(body))
    if result != None:
        print(json.dumps(result, sort_keys=True, indent=2))
    except Exception as e:
        print('Error:') print(e)"


body = {  
    "name":"website-docs-indexer",   
    "dataSourceName" : "website-docs",  
    "skillsetName" : "website-skillset",  
    "targetIndexName" : "website-docs-index",  
    "fieldMappings" : [      
        # Map the soure content fields to index fields        
        {          
            "sourceFieldName" : "metadata_storage_path",          
            "targetFieldName" : "id",          
            "mappingFunction" :             
            { 
                "name" : 
                "base64Encode" 
            }        
        },        
        {          
            "sourceFieldName" : "metadata_storage_path",          
            "targetFieldName" : "url"        
        },        
        {          
            "sourceFieldName" : "metadata_storage_name",          
            "targetFieldName" : "file_name"        },        
        {          
            "sourceFieldName" : "content",          
            "targetFieldName" : "content"        
        },        
        {          
            "sourceFieldName" : "metadata_storage_size",          
            "targetFieldName" : "size"        
        },        
        {          
            "sourceFieldName" : "metadata_storage_last_modified",          
            "targetFieldName" : "last_modified"        
        }   
    ],  
    "outputFieldMappings" :   [      
        # Map the output from cognitive skills to index fields        
        {            
            "sourceFieldName": "/document/normalized_images/*/imageDescription",             
            "targetFieldName": "image_descriptions"        
        },        
        {            
            "sourceFieldName": "/document/normalized_images/*/text",            
            "targetFieldName": "image_text"        
        },        
        {            
            "sourceFieldName": "/document/mergedText",             
            "targetFieldName": "merged_text"        
        },        
        {            
            "sourceFieldName": "/document/sentimentScore",             
            "targetFieldName": "sentiment"        
        },        
        {          
            "sourceFieldName" : "/document/persons",          
            "targetFieldName" : "people"        
        },       
        {          
            "sourceFieldName" : "/document/locations",           
            "targetFieldName" : "locations"        
        },        
        {          
            "sourceFieldName" : "/document/urls",           
            "targetFieldName" : "links"        
        },        
        {          
            "sourceFieldName" : "/document/entities",           
            "targetFieldName" : "entities"        
        },        
        {          
            "sourceFieldName" : "/document/keyPhrases/*",           
            "targetFieldName" : "key_phrases"        
        }  
    ],  
    "parameters":  {    
        "maxFailedItems":-1,    
        "maxFailedItemsPerBatch":-1,    
        "configuration": 
        {        
            "dataToExtract": "contentAndMetadata",        
            "imageAction": "generateNormalizedImages"    
        }  
    }
}  
try:    result = azsearch_rest(request_type="PUT", function_name="indexers/website-docs-indexer", body=json.dumps(body))    
if result != None:        
    print(json.dumps(result, sort_keys=True, indent=2))
except Exception as e:    
    print('Error:')    
print(e)