﻿using System;
using System.Net;
using System.Threading;

namespace Challenge_4
{
    using Microsoft.Azure.Search;
    using Microsoft.Azure.Search.Models;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Spatial;
    using Microsoft.Rest.Azure;
    using System.Collections.Generic;

    class Program
    {
        static void Main(string[] args)
        {
            // Connect to Search Service
            IConfigurationBuilder builder = new ConfigurationBuilder().AddJsonFile("appsettings.json");
            IConfigurationRoot configuration = builder.Build();

            //Uncomment this if you hate Postman and want to create everything in C#
            InitializeAzureSearchProgrammatically(configuration);

            ISearchIndexClient indexClientForQueries = CreateSearchIndexClient(configuration);

            Console.WriteLine("Running Queries");
            RunQueries(indexClientForQueries);
        }

        private static void InitializeAzureSearchProgrammatically(IConfigurationRoot configuration)
        {
            SearchServiceClient serviceClient = CreateSearchServiceClient(configuration);
            //Create index
            Console.WriteLine("{0}", "Creating index...\n");
            CreateIndex(serviceClient, configuration);

            // Create Datasource
            Console.WriteLine("{0}", "Creating Datasource...\n");
            CreateDataSource(serviceClient, configuration);

            // Create Skillset
            Console.WriteLine("{0}", "Creating Skillset...\n");
            CreateSkills(serviceClient, configuration);

            //Create indexer
            Console.WriteLine("{0}", "Creating Indexer...\n");
            CreateIndexer(serviceClient, configuration);

            //Run Indexer
            Console.WriteLine("{0}", "Running Indexer...\n");
            RunIndexer(serviceClient, configuration);
        }

        private static SearchServiceClient CreateSearchServiceClient(IConfigurationRoot configuration)
        {
            string searchServiceName = configuration["SearchServiceName"];
            string adminApiKey = configuration["SearchServiceAdminApiKey"];

            SearchServiceClient serviceClient = new SearchServiceClient(searchServiceName, new SearchCredentials(adminApiKey));
            return serviceClient;
        }
        private static SearchIndexClient CreateSearchIndexClient(IConfigurationRoot configuration)
        {
            string searchServiceName = configuration["SearchServiceName"];
            string queryApiKey = configuration["SearchServiceQueryApiKey"];

            SearchIndexClient indexClient = new SearchIndexClient(searchServiceName, configuration["IndexName"], new SearchCredentials(queryApiKey));
            return indexClient;
        }
        private static void CreateIndex(SearchServiceClient serviceClient, IConfigurationRoot configuration)
        {
            var definition = new Index()
            {
                Name = configuration["IndexName"],
                Fields = FieldBuilder.BuildForType<IndexData>(),
            };

            serviceClient.Indexes.CreateOrUpdate(definition);
        }

        private static void CreateDataSource(SearchServiceClient serviceClient, IConfigurationRoot configuration)
        {
            string connectionstring = configuration["StorageConnectionString"];
            DataSource blobdatasource = DataSource.AzureBlobStorage(
                name: configuration["DatasourceName"],
                storageConnectionString: connectionstring,
                containerName: "docs"
            );

            serviceClient.DataSources.CreateOrUpdate(blobdatasource);
        }

        private static void CreateSkills(SearchServiceClient serviceClient, IConfigurationRoot configuration)
        {
            List<InputFieldMappingEntry> inputMapping = new List<InputFieldMappingEntry>
                {
                    new InputFieldMappingEntry(
                    name: "text",
                    source: "/document/content")
                };

            // Detect the sentiment
            List<OutputFieldMappingEntry> sentimentOutput = new List<OutputFieldMappingEntry>
            {
                new OutputFieldMappingEntry(
                    name: "score",
                    targetName: "sentimentScore"
                )
            };

            SentimentSkill sentimentSkill = new SentimentSkill(
                inputs: inputMapping,
                outputs: sentimentOutput,
                context: "/document",
                description: "Detect Sentiment",
                defaultLanguageCode: SentimentSkillLanguage.En
            );

            //Extract the Entities
            List<OutputFieldMappingEntry> entityOutput = new List<OutputFieldMappingEntry>
                    {
                        new OutputFieldMappingEntry(
                            name: "locations"
                            ),
                        new OutputFieldMappingEntry(
                            name: "persons"
                            ),
                        new OutputFieldMappingEntry(
                            name: "urls"
                            ),
                        new OutputFieldMappingEntry(
                            name: "entities"
                            )
                    };

            List<EntityCategory> entityCategory = new List<EntityCategory>
                    {
                        EntityCategory.Location,
                        EntityCategory.Person,
                        EntityCategory.Url,
                        EntityCategory.Datetime,
                        EntityCategory.Organization
                    };

            EntityRecognitionSkill entityRecognitionSkill = new EntityRecognitionSkill(
                description: "Recognize Entities",
                context: "/document/content",
                inputs: inputMapping,
                outputs: entityOutput,
                categories: entityCategory,
                defaultLanguageCode: EntityRecognitionSkillLanguage.En);

            //Extract key phrases from the pages
            List<OutputFieldMappingEntry> keyPhraseOut = new List<OutputFieldMappingEntry>
            {
                new OutputFieldMappingEntry(
                name: "keyPhrases",
                targetName: "keyPhrases")
            };

            KeyPhraseExtractionSkill keyPhraseExtractionSkill = new KeyPhraseExtractionSkill(
                description: "Extract Key Phrases",
                context: "/document",
                inputs: inputMapping,
                outputs: keyPhraseOut,
                maxKeyPhraseCount: 5
            );

            // Image Analysis to get a description and tags for an image
            List<InputFieldMappingEntry> ImageInputMappings = new List<InputFieldMappingEntry>{
                new InputFieldMappingEntry(
                name: "image",
                source: "/document/normalized_images/*")
            };

            List<OutputFieldMappingEntry> ImageOutputMappings = new List<OutputFieldMappingEntry>{
                new OutputFieldMappingEntry(
                    name: "description",
                    targetName: "imageDescription")
            };

            List<VisualFeature> visualFeatures = new List<VisualFeature>{
                VisualFeature.Description
            };

            ImageAnalysisSkill imageAnalysisSkill = new ImageAnalysisSkill(
                inputs: ImageInputMappings, 
                outputs: ImageOutputMappings, 
                description: "Analyze Images in the document", 
                context: "/document/normalized_images/*",
                visualFeatures: visualFeatures
            );

            //OCR skill to read any text in images
            List<OutputFieldMappingEntry> OcrOutputMappings = new List<OutputFieldMappingEntry>{
                new OutputFieldMappingEntry(
                name: "text",
                targetName: "text")
            };

            OcrSkill ocrSkill = new OcrSkill(
                description: "Extract text (plain and structured) from image",
                context: "/document/normalized_images/*",
                inputs: ImageInputMappings,
                outputs: OcrOutputMappings,
                defaultLanguageCode: OcrSkillLanguage.En,
                shouldDetectOrientation: true);

            // Merge all the text
            List<InputFieldMappingEntry> MergeInputMappings = new List<InputFieldMappingEntry>();
            MergeInputMappings.Add(new InputFieldMappingEntry(
                name: "text",
                source: "/document/content"));
            MergeInputMappings.Add(new InputFieldMappingEntry(
                name: "itemsToInsert",
                source: "/document/normalized_images/*/text"));
            MergeInputMappings.Add(new InputFieldMappingEntry(
                name: "offsets",
                source: "/document/normalized_images/*/contentOffset"));

            List<OutputFieldMappingEntry> MergeOutputMappings = new List<OutputFieldMappingEntry>{
                new OutputFieldMappingEntry(
                name: "mergedText",
                targetName: "merged_text")
            };

            MergeSkill mergeSkill = new MergeSkill(
                description: "Create merged_text which includes all the textual representation of each image inserted at the right location in the content field.",
                context: "/document",
                inputs: MergeInputMappings,
                outputs: MergeOutputMappings,
                insertPreTag: " ",
                insertPostTag: " ");

            // Gather all the skills
            List<Skill> skills = new List<Skill>
            {
                sentimentSkill,
                entityRecognitionSkill,
                keyPhraseExtractionSkill,
                imageAnalysisSkill,
                ocrSkill,
                mergeSkill
            };

            Skillset skillset = new Skillset(
                name: configuration["SkillsetName"],
                description: "Demo skillset",
                skills: skills,
                cognitiveServices: new CognitiveServicesByKey(configuration["CogSvcsKey"]));

            try
            {
                serviceClient.Skillsets.CreateOrUpdate(skillset);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private static void CreateIndexer(SearchServiceClient serviceClient, IConfigurationRoot configuration)
        {
            List<FieldMapping> maps = new List<FieldMapping>{
                new FieldMapping(
                            sourceFieldName: "metadata_storage_name",
                            targetFieldName: "file_name"
                        ),
                new FieldMapping(
                            sourceFieldName: "metadata_storage_path",
                            targetFieldName: "url"
                        ),
                new FieldMapping(
                            sourceFieldName: "metadata_storage_size",
                            targetFieldName: "size"
                        ),
            new FieldMapping(
                            sourceFieldName: "metadata_storage_last_modified",
                            targetFieldName: "last_modified"
                        ),
            new FieldMapping(
                            sourceFieldName: "content",
                            targetFieldName: "content"
                        )
            };
            List<FieldMapping> outputs = new List<FieldMapping>{
                new FieldMapping(
                    sourceFieldName: "/document/sentimentScore",
                    targetFieldName: "sentiment"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/content/persons/*",
                    targetFieldName: "people"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/content/locations/*",
                    targetFieldName: "locations"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/content/urls/*",
                    targetFieldName: "links"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/content/entities/*",
                    targetFieldName: "entities"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/keyPhrases/*",
                    targetFieldName: "key_phrases"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/normalized_images/*/imageDescription",
                    targetFieldName: "image_descriptions"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/normalized_images/*/text",
                    targetFieldName: "image_text"
                ), 
                new FieldMapping(
                    sourceFieldName: "/document/merged_text",
                    targetFieldName: "merged_text"
                )
            };
            IDictionary<string, object> config = new Dictionary<string, object>();
            config.Add(
                key: "dataToExtract",
                value: "contentAndMetadata");
            config.Add(
                key: "imageAction",
                value: "generateNormalizedImages"
            );

            Indexer sqlIndexer = new Indexer(
                name: configuration["IndexerName"],
                dataSourceName: configuration["DatasourceName"],
                targetIndexName: configuration["IndexName"],
                skillsetName: configuration["SkillsetName"],
                fieldMappings: maps,
                parameters: new IndexingParameters(
                    maxFailedItems: -1,
                    maxFailedItemsPerBatch: -1,
                    configuration: config),
                schedule: new IndexingSchedule(TimeSpan.FromDays(1)),
                outputFieldMappings: outputs
            );
            // Indexers contain metadata about how much they have already indexed
            // If we already ran the sample, the indexer will remember that it already
            // indexed the sample data and not run again
            // To avoid this, reset the indexer if it exists
            bool exists = serviceClient.Indexers.Exists(configuration["IndexerName"]);
            if (exists)
            {
                serviceClient.Indexers.Reset(configuration["IndexerName"]);
            }

            serviceClient.Indexers.CreateOrUpdate(sqlIndexer);
        }

        private static void RunIndexer(SearchServiceClient serviceClient, IConfigurationRoot configuration)
        {
            try
            {
                serviceClient.Indexers.Run(configuration["IndexerName"]);
            }
            catch (CloudException e) when (e.Response.StatusCode == (HttpStatusCode)429)
            {
                Console.WriteLine("Failed to run indexer: {0}", e.Response.Content);
            }
            Console.WriteLine("Waiting for documents to be indexed...\n");
            try
            {
                IndexerExecutionInfo executionInfo = serviceClient.Indexers.GetStatus(configuration["IndexerName"]);
                while (executionInfo.LastResult.Status != IndexerExecutionStatus.Success && executionInfo.LastResult.Status != IndexerExecutionStatus.TransientFailure)
                {
                    Thread.Sleep(500);
                    executionInfo = serviceClient.Indexers.GetStatus(configuration["IndexerName"]);
                    switch (executionInfo.LastResult.Status)
                    {
                        case IndexerExecutionStatus.TransientFailure:
                            Console.WriteLine("Indexer has error status");
                            break;
                        case IndexerExecutionStatus.InProgress:
                            Console.WriteLine("Indexer is running");
                            break;
                        case IndexerExecutionStatus.Success:
                            Console.WriteLine("Indexer has completed");
                            break;
                        default:
                            Console.WriteLine("Indexer has reset");
                            break;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private static void RunQueries(ISearchIndexClient indexClient)
        {
            SearchParameters parameters;
            DocumentSearchResult<IndexData> results;

            //Find the key talking points and sentiment score for each review of a hotel in New York.
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Review Sentiment and Key Phrases for New York:");

            parameters =
                new SearchParameters()
                {
                    Select = new[] { "url", "file_name", "key_phrases", "sentiment" },
                    SearchFields = new[] { "content" },
                    Filter = "search.ismatch('reviews', 'url')",
                    OrderBy = new[] { "sentiment desc" },
                };

            results = indexClient.Documents.Search<IndexData>("\"New York\"", parameters);
            foreach (SearchResult<IndexData> result in results.Results)
            {
                Console.WriteLine("url: {0}", result.Document.Url);
                Console.WriteLine("File Name: {0}", result.Document.File_name);
                Console.WriteLine("Sentiment: {0}", result.Document.Sentiment);
                Console.WriteLine("Key Phrases: {0}", string.Join(", ", result.Document.Key_phrases));

            }
            Console.WriteLine();

            //Find reviews of hotels in New York that mention the location Broadway.
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Search Results by City and Locations:\n\n");

            parameters =
                new SearchParameters()
                {
                    Filter = "search.ismatch('reviews', 'url')",
                    QueryType = QueryType.Full,
                    SearchMode = SearchMode.All,
                    Select = new[] { "url", "file_name", "sentiment", "locations" }
                };

            results = indexClient.Documents.Search<IndexData>("\"New York\"+locations:Broadway", parameters);
            foreach (SearchResult<IndexData> result in results.Results)
            {
                Console.WriteLine("url: {0}", result.Document.Url);
                Console.WriteLine("File Name: {0}", result.Document.File_name);
                Console.WriteLine("Sentiment: {0}", result.Document.Sentiment);
                Console.WriteLine("Locations: {0}", string.Join(", ", result.Document.Locations));

            }
            Console.WriteLine();

            //Find the key phrases and sentiment scores of reviews written by Matthew Daughtry
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Reviews by Reviewer:\n\n");

            parameters =
                new SearchParameters()
                {
                    OrderBy = new[] { "last_modified desc" },
                    Filter = "search.ismatch('reviews', 'url')",
                    QueryType = QueryType.Full,
                    Select = new[] { "file_name", "url", "key_phrases", "sentiment", "people" }
                };

            results = indexClient.Documents.Search<IndexData>("people:\"Matthew Daughtry\"", parameters);

            foreach (SearchResult<IndexData> result in results.Results)
            {
                Console.WriteLine("url: {0}", result.Document.Url);
                Console.WriteLine("File Name: {0}", result.Document.File_name);
                Console.WriteLine("Key Phrases: {0}", string.Join(", ", result.Document.Key_phrases));
                Console.WriteLine("Sentiment: {0}", result.Document.Sentiment);
                Console.WriteLine("People: {0}", string.Join(", ", result.Document.People));

            }
            Console.WriteLine();

            //Filter reviews of hotels in Las Vegas to show only the negative ones (defined as having a sentiment score of 0.5 or lower).
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Negative Reviews: \n\n");

            parameters =
                new SearchParameters()
                {
                    Select = new[] { "file_name", "url", "key_phrases", "sentiment", "locations" },
                    SearchMode = SearchMode.All,
                    Filter = "search.ismatch('reviews', 'url') and sentiment le 0.5",
                    OrderBy = new[] { "sentiment desc" }
                };

            results = indexClient.Documents.Search<IndexData>("Las Vegas", parameters);

            foreach (SearchResult<IndexData> result in results.Results)
            {
                Console.WriteLine("url: {0}", result.Document.Url);
                Console.WriteLine("File Name: {0}", result.Document.File_name);
                Console.WriteLine("Key Phrases: {0}", string.Join(", ", result.Document.Key_phrases));
                Console.WriteLine("Locations: {0}", string.Join(", ", result.Document.Locations));
                Console.WriteLine("Sentiment: {0}", result.Document.Sentiment);

            }
            Console.WriteLine();

            //Filter search results to include only collateral documents that contain URLs.
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Collateral containing links \n\n");

            parameters =
                new SearchParameters()
                {
                    Select = new[] { "file_name", "url", "links" },
                    Filter = "search.ismatch('collateral', 'url') and links/any()",
                    SearchMode = SearchMode.All,
                    QueryType = QueryType.Full
                };

            results = indexClient.Documents.Search<IndexData>("*", parameters);
            foreach (SearchResult<IndexData> result in results.Results)
            {
                Console.WriteLine("url: {0}", result.Document.Url);
                Console.WriteLine("File Name: {0}", result.Document.File_name);
                Console.WriteLine("Links: {0}", string.Join(", ", result.Document.Links));

            }
            Console.WriteLine();

            //Show results of collateral with statue of liberty in merged text and image descriptions
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Collateral with Statue of Liberty (and images) \n\n");

            parameters =
                new SearchParameters()
                {
                    Select = new[] { "file_name", "url", "merged_text", "image_descriptions" },
                    Filter = "search.ismatch('collateral', 'url')",
                    SearchMode = SearchMode.All,
                    QueryType = QueryType.Full
                };

            results = indexClient.Documents.Search<IndexData>("Statue of Liberty", parameters);
            foreach (SearchResult<IndexData> result in results.Results)
            {
                Console.WriteLine("url: {0}", result.Document.Url);
                Console.WriteLine("File Name: {0}", result.Document.File_name);
                Console.WriteLine("Image_descriptions: {0}", string.Join(", ", result.Document.Image_descriptions));
                Console.WriteLine("Merged Text: {0}", result.Document.Merged_text);
            }
            Console.WriteLine();

        }

    }
}
