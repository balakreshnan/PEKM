﻿namespace Challenge_7
{
    using System;
    using System.Net;
    using System.Net.Http;
    using System.Threading;
    using System.Text;
    using System.Linq;
    using Microsoft.Azure.Search;
    using Microsoft.Azure.Search.Models;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Rest.Azure;
    using System.Collections.Generic;
    using System.IO;

    class Program
    {
        static void Main(string[] args)
        {
            // Connect to Search Service
            IConfigurationBuilder builder = new ConfigurationBuilder().AddJsonFile("appsettings.json");
            IConfigurationRoot configuration = builder.Build();

            //Uncomment this if you hate Postman and want to create everything in C#
            InitializeAzureSearchProgrammatically(configuration);

            ISearchIndexClient indexClientForQueries = CreateSearchIndexClient(configuration);

            Console.WriteLine("Running Queries");
            RunQueries(indexClientForQueries);
        }

        private static void InitializeAzureSearchProgrammatically(IConfigurationRoot configuration)
        {
            SearchServiceClient serviceClient = CreateSearchServiceClient(configuration);
            //Create index
            Console.WriteLine("{0}", "Creating index...\n");
            CreateIndex(serviceClient, configuration);

            // Create Datasource
            Console.WriteLine("{0}", "Creating Datasource...\n");
            CreateDataSource(serviceClient, configuration);

            // Create Skillset
            Console.WriteLine("{0}", "Creating Skillset...\n");
            CreateSkills(serviceClient, configuration);

            Console.WriteLine("{0}", "Creating synonyms...\n");
            CreateSynonymMaps(serviceClient, configuration);
            Index index = serviceClient.Indexes.Get(configuration["IndexName"]);
            index = AddSynonymMapsToFields(index);
            serviceClient.Indexes.CreateOrUpdate(index);

            //Create indexer
            Console.WriteLine("{0}", "Creating Indexer...\n");
            CreateIndexer(serviceClient, configuration);

            //Run Indexer
            Console.WriteLine("{0}", "Running Indexer...\n");
            RunIndexer(serviceClient, configuration);
        }

        private static SearchServiceClient CreateSearchServiceClient(IConfigurationRoot configuration)
        {
            string searchServiceName = configuration["SearchServiceName"];
            string adminApiKey = configuration["SearchServiceAdminApiKey"];

            SearchServiceClient serviceClient = new SearchServiceClient(searchServiceName, new SearchCredentials(adminApiKey));
            return serviceClient;
        }
        private static SearchIndexClient CreateSearchIndexClient(IConfigurationRoot configuration)
        {
            string searchServiceName = configuration["SearchServiceName"];
            string queryApiKey = configuration["SearchServiceQueryApiKey"];

            SearchIndexClient indexClient = new SearchIndexClient(searchServiceName, configuration["IndexName"], new SearchCredentials(queryApiKey));
            return indexClient;
        }
        private static void CreateIndex(SearchServiceClient serviceClient, IConfigurationRoot configuration)
        {
            List<string> fields = new List<string>{
                "locations"
            };

            List<Suggester> suggesters = new List<Suggester>{
                new Suggester(
                    name: "suggestions",
                    sourceFields: fields
                )
            };

            List<ScoringFunction> functions = new List<ScoringFunction>{
                        new MagnitudeScoringFunction("size", 2, 1000, 50000, true, ScoringFunctionInterpolation.Linear),
                        new FreshnessScoringFunction("last_modified", 2, new TimeSpan(2400,0,0), ScoringFunctionInterpolation.Quadratic)
            };

            Dictionary<string, double> weights = new Dictionary<string, double>{
                {"key_phrases", 5}
            };

            List<ScoringProfile> scoringProfiles = new List<ScoringProfile>{
                new ScoringProfile(
                    name: "booster",
                    textWeights: new TextWeights(weights),
                    functions: functions
                )
            };

            Index definition = new Index()
            {
                Name = configuration["IndexName"],
                Fields = FieldBuilder.BuildForType<IndexData>(),
                Suggesters = suggesters,
                ScoringProfiles = scoringProfiles
            };

            serviceClient.Indexes.CreateOrUpdate(definition);
        }

        private static Index AddSynonymMapsToFields(Index index)
        {
            index.Fields.First(f => f.Name == "url").SynonymMaps = new[] { "loc-synmap" };
            index.Fields.First(f => f.Name == "content").SynonymMaps = new[] { "loc-synmap" };
            index.Fields.First(f => f.Name == "key_phrases").SynonymMaps = new[] { "loc-synmap" };
            index.Fields.First(f => f.Name == "locations").SynonymMaps = new[] { "loc-synmap" };
            index.Fields.First(f => f.Name == "links").SynonymMaps = new[] { "loc-synmap" };
            index.Fields.First(f => f.Name == "entities").SynonymMaps = new[] { "loc-synmap" };
            index.Fields.First(f => f.Name == "image_descriptions").SynonymMaps = new[] { "loc-synmap" };
            index.Fields.First(f => f.Name == "image_text").SynonymMaps = new[] { "loc-synmap" };
            index.Fields.First(f => f.Name == "merged_text").SynonymMaps = new[] { "loc-synmap" };
            index.Fields.First(f => f.Name == "top_words").SynonymMaps = new[] { "loc-synmap" };
            return index;
        }


        private static void CreateDataSource(SearchServiceClient serviceClient, IConfigurationRoot configuration)
        {
            string connectionstring = configuration["StorageConnectionString"];
            DataSource blobdatasource = DataSource.AzureBlobStorage(
                name: configuration["DatasourceName"],
                storageConnectionString: connectionstring,
                containerName: "docs"
            );

            serviceClient.DataSources.CreateOrUpdate(blobdatasource);
        }

        /*
        For challenge 7, instead of using the SDK to define the skills, a call to the REST endpoint is used. This is because
        Knowledge stores aren't supported by the SDK yet.
         */
        private static void CreateSkills(SearchServiceClient serviceClient, IConfigurationRoot configuration)
        {
            #region DotnetSkills
            // // Note - the region commented out below is the SDK way of doing things. We're going to be manually
            // // defining our skillset as a custom object to add the Type properties that the REST endpoint expects.
            // List<InputFieldMappingEntry> inputMapping = new List<InputFieldMappingEntry>
            //     {
            //         new InputFieldMappingEntry(
            //         name: "text",
            //         source: "/document/content")
            //     };

            // // Detect the sentiment
            // List<OutputFieldMappingEntry> sentimentOutput = new List<OutputFieldMappingEntry>
            // {
            //     new OutputFieldMappingEntry(
            //         name: "score",
            //         targetName: "sentimentScore"
            //     )
            // };

            // SentimentSkill sentimentSkill = new SentimentSkill(
            //     inputs: inputMapping,
            //     outputs: sentimentOutput,
            //     context: "/document",
            //     description: "Detect Sentiment",
            //     defaultLanguageCode: SentimentSkillLanguage.En
            // );

            // //Extract the Entities
            // List<OutputFieldMappingEntry> entityOutput = new List<OutputFieldMappingEntry>
            //         {
            //             new OutputFieldMappingEntry(
            //                 name: "locations"
            //                 ),
            //             new OutputFieldMappingEntry(
            //                 name: "persons"
            //                 ),
            //             new OutputFieldMappingEntry(
            //                 name: "urls"
            //                 ),
            //             new OutputFieldMappingEntry(
            //                 name: "entities"
            //                 )
            //         };

            // List<EntityCategory> entityCategory = new List<EntityCategory>
            //         {
            //             EntityCategory.Location,
            //             EntityCategory.Person,
            //             EntityCategory.Url,
            //             EntityCategory.Datetime,
            //             EntityCategory.Organization
            //         };

            // EntityRecognitionSkill entityRecognitionSkill = new EntityRecognitionSkill(
            //     description: "Recognize Entities",
            //     context: "/document/content",
            //     inputs: inputMapping,
            //     outputs: entityOutput,
            //     categories: entityCategory,
            //     defaultLanguageCode: EntityRecognitionSkillLanguage.En);

            // //Extract key phrases from the pages
            // List<OutputFieldMappingEntry> keyPhraseOut = new List<OutputFieldMappingEntry>
            // {
            //     new OutputFieldMappingEntry(
            //     name: "keyPhrases",
            //     targetName: "keyPhrases")
            // };

            // KeyPhraseExtractionSkill keyPhraseExtractionSkill = new KeyPhraseExtractionSkill(
            //     description: "Extract Key Phrases",
            //     context: "/document",
            //     inputs: inputMapping,
            //     outputs: keyPhraseOut,
            //     maxKeyPhraseCount: 5
            // );

            // // Image Analysis to get a description and tags for an image
            // List<InputFieldMappingEntry> ImageInputMappings = new List<InputFieldMappingEntry>{
            //     new InputFieldMappingEntry(
            //     name: "image",
            //     source: "/document/normalized_images/*")
            // };

            // List<OutputFieldMappingEntry> ImageOutputMappings = new List<OutputFieldMappingEntry>{
            //     new OutputFieldMappingEntry(
            //         name: "description",
            //         targetName: "imageDescription")
            // };

            // List<VisualFeature> visualFeatures = new List<VisualFeature>{
            //     VisualFeature.Description
            // };

            // ImageAnalysisSkill imageAnalysisSkill = new ImageAnalysisSkill(
            //     inputs: ImageInputMappings,
            //     outputs: ImageOutputMappings,
            //     description: "Analyze Images in the document",
            //     context: "/document/normalized_images/*",
            //     visualFeatures: visualFeatures
            // );

            // //OCR skill to read any text in images
            // List<OutputFieldMappingEntry> OcrOutputMappings = new List<OutputFieldMappingEntry>{
            //     new OutputFieldMappingEntry(
            //     name: "text",
            //     targetName: "text")
            // };

            // OcrSkill ocrSkill = new OcrSkill(
            //     description: "Extract text (plain and structured) from image",
            //     context: "/document/normalized_images/*",
            //     inputs: ImageInputMappings,
            //     outputs: OcrOutputMappings,
            //     defaultLanguageCode: OcrSkillLanguage.En,
            //     shouldDetectOrientation: true);

            // // Merge all the text
            // List<InputFieldMappingEntry> MergeInputMappings = new List<InputFieldMappingEntry>();
            // MergeInputMappings.Add(new InputFieldMappingEntry(
            //     name: "text",
            //     source: "/document/content"));
            // MergeInputMappings.Add(new InputFieldMappingEntry(
            //     name: "itemsToInsert",
            //     source: "/document/normalized_images/*/text"));
            // MergeInputMappings.Add(new InputFieldMappingEntry(
            //     name: "offsets",
            //     source: "/document/normalized_images/*/contentOffset"));

            // List<OutputFieldMappingEntry> MergeOutputMappings = new List<OutputFieldMappingEntry>{
            //     new OutputFieldMappingEntry(
            //     name: "mergedText",
            //     targetName: "merged_text")
            // };

            // MergeSkill mergeSkill = new MergeSkill(
            //     description: "Create merged_text which includes all the textual representation of each image inserted at the right location in the content field.",
            //     context: "/document",
            //     inputs: MergeInputMappings,
            //     outputs: MergeOutputMappings,
            //     insertPreTag: "[",
            //     insertPostTag: "]");

            // // Custom Skill
            // List<InputFieldMappingEntry> CountInputMappings = new List<InputFieldMappingEntry>{
            //     new InputFieldMappingEntry(
            //     name: "mergedText",
            //     source: "/document/merged_text")
            // };

            // List<OutputFieldMappingEntry> CountOutputMappings = new List<OutputFieldMappingEntry>{
            //     new OutputFieldMappingEntry(
            //     name: "topWords",
            //     targetName: "top_words")
            // };

            // string apiUri = configuration["WebApiUri"];

            // WebApiSkill customSkill = new WebApiSkill(
            //     inputs: CountInputMappings,
            //     outputs: CountOutputMappings,
            //     uri: apiUri,
            //     name: "counter",
            //     description: "Custom Skill counting top words",
            //     context: "/document",
            //     httpMethod: "post",
            //     batchSize: 1
            // );


            // // Map the fields into something more manageable for the projections
            // List<InputFieldMappingEntry> shaperInputs = new List<InputFieldMappingEntry>{
            //     new InputFieldMappingEntry(
            //         name: "file_id",
            //         source: "/document/id"
            //     ),
            //     new InputFieldMappingEntry(
            //         name: "file_name",
            //         source: "/document/file_name"
            //     ),
            //     new InputFieldMappingEntry(
            //         name: "url",
            //         source: "/document/url"
            //     ),
            //     new InputFieldMappingEntry(
            //         name: "top_words",
            //         source: "/document/top_words/*"
            //     ),
            //     new InputFieldMappingEntry(
            //         name: "sentiment_score",
            //         source: "/document/sentimentScore"
            //     ),
            //     new InputFieldMappingEntry(
            //         name: "locations",
            //         source: "/document/content/locations/*"
            //     )
            // };

            // List<OutputFieldMappingEntry> shaperOutputs = new List<OutputFieldMappingEntry>{
            //     new OutputFieldMappingEntry(
            //         name: "output",
            //         targetName: "projection"
            //     )
            // };

            // // Create projections
            // ShaperSkill shaper = new ShaperSkill(
            //     name: "Projection Shaper",
            //     description: "Shape projections",
            //     context: "/document",
            //     inputs: shaperInputs,
            //     outputs: shaperOutputs
            // );

            // Gather all the skills

            // List<Skill> skills = new List<Skill>
            // {
            //     sentimentSkill,
            //     entityRecognitionSkill,
            //     keyPhraseExtractionSkill,
            //     imageAnalysisSkill,
            //     ocrSkill,
            //     mergeSkill,
            //     customSkill
            // };

            // Skillset skillset = new Skillset(
            //     name: configuration["SkillsetName"],
            //     description: "Demo skillset",
            //     skills: skills,
            //     cognitiveServices: new CognitiveServicesByKey(configuration["CogSvcsKey"]));
            // try
            // {
            //     serviceClient.Skillsets.CreateOrUpdate(skillset);
            // }
            // catch (Exception e)
            // {
            //     Console.WriteLine(e);
            // }
            #endregion

            // This is the manual definition of the skillset (using a JSON file)
            #region JSONpayload
            
            StreamReader r = new StreamReader("skills.json");
            string skillDef = r.ReadToEnd(); 

            UriBuilder builder = new UriBuilder("https://"+configuration["SearchServiceName"]+".search.windows.net"+"/skillsets/"+configuration["SkillsetName"]);
            builder.Query = "api-version=2019-05-06-Preview";
           
            //Send the JSON payload
            try{

                var request = new HttpRequestMessage() {
                    RequestUri = builder.Uri,
                    Method = HttpMethod.Put
                };

                request.Headers.Add("api-key", configuration["SearchServiceAdminApiKey"]);
                request.Content = new StringContent(skillDef, Encoding.UTF8, "application/json");

                var response = client.SendAsync(request).Result;
                response.EnsureSuccessStatusCode();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            #endregion

        }

        private static void CreateSynonymMaps(SearchServiceClient serviceClient, IConfigurationRoot configuration)
        {
            SynonymMap synonymMap = new SynonymMap()
            {
                Name = "loc-synmap",
                Synonyms = "USA, United States, America, United States of America\n" +
                            "UK, United Kingdom, Britain, Great Britain\n" +
                            "UAE, United Arab Emirates, Emirates"
            };

            serviceClient.SynonymMaps.CreateOrUpdate(synonymMap);

        }
        private static void CreateIndexer(SearchServiceClient serviceClient, IConfigurationRoot configuration)
        {
            List<FieldMapping> maps = new List<FieldMapping>{
                new FieldMapping(
                            sourceFieldName: "metadata_storage_name",
                            targetFieldName: "file_name"
                        ),
                new FieldMapping(
                            sourceFieldName: "metadata_storage_path",
                            targetFieldName: "url"
                        ),
                new FieldMapping(
                            sourceFieldName: "metadata_storage_size",
                            targetFieldName: "size"
                        ),
            new FieldMapping(
                            sourceFieldName: "metadata_storage_last_modified",
                            targetFieldName: "last_modified"
                        ),
            new FieldMapping(
                            sourceFieldName: "content",
                            targetFieldName: "content"
                        )
            };
            List<FieldMapping> outputs = new List<FieldMapping>{
                new FieldMapping(
                    sourceFieldName: "/document/sentimentScore",
                    targetFieldName: "sentiment"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/content/persons/*",
                    targetFieldName: "people"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/content/locations/*",
                    targetFieldName: "locations"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/content/urls/*",
                    targetFieldName: "links"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/content/entities/*",
                    targetFieldName: "entities"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/keyPhrases/*",
                    targetFieldName: "key_phrases"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/normalized_images/*/imageDescription",
                    targetFieldName: "image_descriptions"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/normalized_images/*/text",
                    targetFieldName: "image_text"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/merged_text",
                    targetFieldName: "merged_text"
                ),
                new FieldMapping(
                    sourceFieldName: "/document/top_words",
                    targetFieldName: "top_words"
                )
            };
            IDictionary<string, object> config = new Dictionary<string, object>();
            config.Add(
                key: "dataToExtract",
                value: "contentAndMetadata");
            config.Add(
                key: "imageAction",
                value: "generateNormalizedImages"
            );

            Indexer sqlIndexer = new Indexer(
                name: configuration["IndexerName"],
                dataSourceName: configuration["DatasourceName"],
                targetIndexName: configuration["IndexName"],
                skillsetName: configuration["SkillsetName"],
                fieldMappings: maps,
                parameters: new IndexingParameters(
                    maxFailedItems: -1,
                    maxFailedItemsPerBatch: -1,
                    configuration: config),
                schedule: new IndexingSchedule(TimeSpan.FromDays(1)),
                outputFieldMappings: outputs
            );
            // We need to reset the Index if we run again, otherwise it will not update already indexed items
            bool exists = serviceClient.Indexers.Exists(configuration["IndexerName"]);
            if (exists)
            {
                serviceClient.Indexers.Reset(configuration["IndexerName"]);
            }

            serviceClient.Indexers.CreateOrUpdate(sqlIndexer);
        }

        private static void RunIndexer(SearchServiceClient serviceClient, IConfigurationRoot configuration)
        {

            try
            {
                serviceClient.Indexers.Run(configuration["IndexerName"]);
            }
            catch (CloudException e) when (e.Response.StatusCode == (HttpStatusCode)429)
            {
                Console.WriteLine("Failed to run indexer: {0}", e.Response.Content);
            }
            Console.WriteLine("Waiting for documents to be indexed...\n");
            try
            {
                IndexerExecutionInfo executionInfo = serviceClient.Indexers.GetStatus(configuration["IndexerName"]);
                while (executionInfo.LastResult.Status != IndexerExecutionStatus.Success && executionInfo.LastResult.Status != IndexerExecutionStatus.TransientFailure)
                {
                    Thread.Sleep(500);
                    executionInfo = serviceClient.Indexers.GetStatus(configuration["IndexerName"]);
                    switch (executionInfo.LastResult.Status)
                    {
                        case IndexerExecutionStatus.TransientFailure:
                            Console.WriteLine("Indexer has error status");
                            break;
                        case IndexerExecutionStatus.InProgress:
                            Console.WriteLine("Indexer is running");
                            break;
                        case IndexerExecutionStatus.Success:
                            Console.WriteLine("Indexer has completed");
                            break;
                        default:
                            Console.WriteLine("Indexer has reset");
                            break;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private static void RunQueries(ISearchIndexClient indexClient)
        {
            SearchParameters parameters;
            DocumentSearchResult<IndexData> results;

            //Search of synonyms of Britain
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Synonyms of Britain \n\n");

            parameters =
                new SearchParameters()
                {
                    Select = new[] { "file_name", "content", "locations" },
                    SearchMode = SearchMode.All,
                    QueryType = QueryType.Full
                };

            results = indexClient.Documents.Search<IndexData>("Britain", parameters);
            foreach (SearchResult<IndexData> result in results.Results)
            {
                Console.WriteLine("File Name: {0}", result.Document.File_name);
                Console.WriteLine("Content: {0}", result.Document.Content);
                Console.WriteLine("Locations: {0}", string.Join(", ", result.Document.Locations));
            }
            Console.WriteLine();

            //displays suggestions and autocomplete options for partial user input based on the *Location* field. 
            //For example, typing "San" should produce suggestions for "**San** Francisco" and "**San** Diego"
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Suggest something for San \n\n");

            SuggestParameters par = new SuggestParameters()
            {
                Top = 15
            };

            AutocompleteParameters ap = new AutocompleteParameters()
            {
                AutocompleteMode = AutocompleteMode.TwoTerms
            };

            var autoComplete = indexClient.Documents.Autocomplete("San", "suggestions", ap);
            Console.WriteLine("Autocomplete options:");
            foreach (var result in autoComplete.Results)
            {
                Console.WriteLine(result.Text);
            }

            var suggests = indexClient.Documents.Suggest<IndexData>("San", "suggestions", par);

            Console.WriteLine("\nSuggestion options:");

            foreach (var result in suggests.Results)
            {
                Console.WriteLine("File Name:{0}", result.Document.File_name);
                Console.WriteLine("Locations:{0}\n", string.Join(",", result.Document.Locations));
            }

            Console.WriteLine();

            //Apply a scoring profile to increase the search score of results based on term inclusion in key phrases, 
            //document size, and last modified date. For example, searching for "quiet" should boost results where the word "quiet" is included in the key phrases field.
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Search for quiet with boosting \n\n");

            parameters =
                new SearchParameters()
                {
                    Select = new[] { "size", "key_phrases", "file_name", "last_modified" },
                    ScoringProfile = "booster",
                    QueryType = QueryType.Full,
                    SearchMode = SearchMode.All,
                    Filter = "search.ismatch('reviews', 'url')"
                };

            results = indexClient.Documents.Search<IndexData>("quiet", parameters);
            foreach (SearchResult<IndexData> result in results.Results)
            {
                Console.WriteLine("Score: {0}", result.Score);
                Console.WriteLine("File Name: {0}", result.Document.File_name);
                Console.WriteLine("Key Phrases: {0}", string.Join(',', result.Document.Key_phrases));
                Console.WriteLine("Size: {0}", result.Document.Size);
                Console.WriteLine("Last Modified: {0}\n\n", result.Document.Last_modified);

            }
            Console.WriteLine();
        }

    }
}
