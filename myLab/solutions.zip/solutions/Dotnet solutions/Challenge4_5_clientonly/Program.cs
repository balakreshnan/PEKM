﻿using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
using Microsoft.Extensions.Configuration;
using System;

namespace Challenge4_5_clientonly
{
    class Program
    {
        static void Main(string[] args)
        {
            IConfigurationBuilder builder = new ConfigurationBuilder().AddJsonFile("appsettings.json");
            IConfigurationRoot configuration = builder.Build();

            ISearchIndexClient indexClientForQueries = CreateSearchIndexClient(configuration);

            Console.WriteLine("Running Queries");
            RunQueries(indexClientForQueries);
        }

        private static SearchIndexClient CreateSearchIndexClient(IConfigurationRoot configuration)
        {
            string searchServiceName = configuration["SearchServiceName"];
            string queryApiKey = configuration["SearchServiceQueryApiKey"];

            SearchIndexClient indexClient = new SearchIndexClient(searchServiceName, configuration["IndexName"], new SearchCredentials(queryApiKey));
            return indexClient;
        }

        private static void RunQueries(ISearchIndexClient indexClient)
        {
            SearchParameters parameters;
            DocumentSearchResult<IndexData> results;

            //challenge 4

            //The AI-generated image captions and any OCR text extracted from images in collateral 
            //documents that match submitted search terms and contain images. 
            //For example, a search for "Grand Canyon" should result in a list of documents that include 
            //both this term and one or more images; and for each document in the results, 
            //the AI-generated caption and OCR extracted text from each image should be displayed.
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Collateral containing images \n\n");

            parameters =
                new SearchParameters()
                {
                    Select = new[] { "file_name", "url", "image_descriptions", "image_text", "merged_text" },
                    Filter = "search.ismatch('collateral', 'url') and image_descriptions/any()",
                    SearchMode = SearchMode.All,
                    QueryType = QueryType.Full
                };

            results = indexClient.Documents.Search<IndexData>("Grand Canyon", parameters);
            foreach (SearchResult<IndexData> result in results.Results)
            {
                Console.WriteLine("url: {0}", result.Document.Url);
                Console.WriteLine("File Name: {0}", result.Document.File_name);
                Console.WriteLine("Image Descriptions: {0}", string.Join(',',result.Document.Image_descriptions));
                Console.WriteLine("Image Text: {0}", string.Join(',',result.Document.Image_text));

            }
            Console.WriteLine();

            //Documents in which images contain AI-generated captions or tags that match the submitted search 
            //terms. For example, a search for "bridge" should return a list of documents that contain an image 
            //in which the AI-generated caption or tags contains the word "bridge".
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Collateral containing images \n\n");

            parameters =
                new SearchParameters()
                {
                    Select = new[] { "file_name", "url", "image_descriptions", "image_text", "merged_text" },
                    Filter = "image_descriptions/any()",
                    SearchMode = SearchMode.All,
                    QueryType = QueryType.Full
                };

            results = indexClient.Documents.Search<IndexData>("image_descriptions:bridge", parameters);
            foreach (SearchResult<IndexData> result in results.Results)
            {
                Console.WriteLine("url: {0}", result.Document.Url);
                Console.WriteLine("File Name: {0}", result.Document.File_name);
                Console.WriteLine("Image Descriptions: {0}", string.Join(',', result.Document.Image_descriptions));
                Console.WriteLine("Image Text: {0}", string.Join(',', result.Document.Image_text));

            }
            Console.WriteLine();


            //challenge 5
            //Modify your client application so that users can filter search results based on the presence of a specified keyword in the top ten list.
            Console.WriteLine("**************************************************************************");
            Console.WriteLine("Top Words \n\n");

            parameters =
                new SearchParameters()
                {
                    Select = new[] { "file_name", "url", "top_words" },
                    SearchMode = SearchMode.All,
                    QueryType = QueryType.Full
                };

            results = indexClient.Documents.Search<IndexData>("top_words:dubai", parameters);
            foreach (SearchResult<IndexData> result in results.Results)
            {
                Console.WriteLine("url: {0}", result.Document.Url);
                Console.WriteLine("File Name: {0}", result.Document.File_name);
                Console.WriteLine("Top Words: {0}", string.Join(',',result.Document.Top_words));

            }
            Console.WriteLine();

        }
    }
}
