﻿using Microsoft.Extensions.Configuration;
using System;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;

namespace Challenge_1
{
    class Program
    {
        static void Main(string[] args)
        {
            IConfigurationBuilder builder = new ConfigurationBuilder().AddJsonFile("appsettings.json");
            IConfigurationRoot configuration = builder.Build();

            // Represents the various elements used to create HTTP request URIs
            // for QnA Maker operations.
            // From Publish Page: HOST
            // Example: https://YOUR-RESOURCE-NAME.azurewebsites.net/qnamaker
            string host = configuration["host"];

            // Authorization endpoint key
            // From Publish Page
            string endpoint_key = configuration["endpoint_key"];

            // Management APIs postpend the version to the route
            // From Publish Page, value after POST
            // Example: /knowledgebases/ZZZ15f8c-d01b-4698-a2de-85b0dbf3358c/generateAnswer
            string route = configuration["route"];

            // JSON format for passing question to service
            Console.WriteLine("What's your question?");
            string input = Console.ReadLine();
            string question = @"{'question': '" + input + "','top': 3}";
            Console.WriteLine(question);

            // Create http client
            using (var client = new HttpClient())
            using (var request = new HttpRequestMessage())
            {
                // POST method
                request.Method = HttpMethod.Post;

                // Add host + service to get full URI
                request.RequestUri = new Uri(host + route);

                // set question
                request.Content = new StringContent(question, Encoding.UTF8, "application/json");
                
                // set authorization
                request.Headers.Add("Authorization", "EndpointKey " + endpoint_key);

                // Send request to Azure service, get response
                var response = client.SendAsync(request).Result;
                var jsonResponse = response.Content.ReadAsStringAsync().Result;

                var answers=JsonConvert.DeserializeObject<Answers>(jsonResponse);

                Console.WriteLine("We found the following answers:");

                foreach (var answer in answers.answers)
                {
                    Console.WriteLine("{0}\nscore:{1}\n\n",answer.answer,answer.score);
                }

                
            }
        }
    }
}
