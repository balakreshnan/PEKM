namespace Challenge_3
{
    using System;
    using System.Collections.Generic;
    using Microsoft.Azure.Search;
    using Microsoft.Azure.Search.Models;
    using Microsoft.Spatial;
    using Newtonsoft.Json;

    [SerializePropertyNamesAsCamelCase]
    public partial class IndexData
    {
        [System.ComponentModel.DataAnnotations.Key]
        [IsFilterable]
        public string Id { get; set; }

        [IsFilterable, IsSortable, IsFacetable, IsSearchable]
        public string Url { get; set; }

        [IsFilterable, IsSortable, IsFacetable]
        public string File_name { get; set; }

        [IsSearchable]
        public string Content { get; set; }

        [IsFilterable, IsSortable]
        public int Size { get; set; }

        [IsFilterable, IsSortable, IsFacetable]
        public DateTime Last_modified { get; set; }

        [IsSearchable]
        public string[] Key_phrases {get; set;}

        [IsSortable, IsFacetable, IsFilterable]
        public Double Sentiment {get; set;}

        [IsSearchable, IsFilterable]
        public string[] Locations {get; set;}

        [IsSearchable, IsFilterable]
        public string[] People {get; set;}

        [IsSearchable, IsFilterable]
        public string[] Links {get; set;}

        [IsSearchable, IsFilterable]
        public string[] Entities {get; set;}
    }
}