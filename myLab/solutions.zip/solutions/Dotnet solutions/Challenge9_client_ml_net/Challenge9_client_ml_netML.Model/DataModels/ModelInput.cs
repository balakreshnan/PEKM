//*****************************************************************************************
//*                                                                                       *
//* This is an auto-generated file by Microsoft ML.NET CLI (Command-Line Interface) tool. *
//*                                                                                       *
//*****************************************************************************************

using Microsoft.ML.Data;

namespace Challenge9_client_ml_netML.Model.DataModels
{
    public class ModelInput
    {
        [ColumnName("AgeOnDeparture"), LoadColumn(0)]
        public float AgeOnDeparture { get; set; }


        [ColumnName("Destination"), LoadColumn(1)]
        public string Destination { get; set; }


        [ColumnName("DepartureMonth"), LoadColumn(2)]
        public float DepartureMonth { get; set; }


        [ColumnName("DurationOfStay_Days"), LoadColumn(3)]
        public float DurationOfStay_Days { get; set; }


        [ColumnName("Claim"), LoadColumn(4)]
        public bool Claim { get; set; }


    }
}
