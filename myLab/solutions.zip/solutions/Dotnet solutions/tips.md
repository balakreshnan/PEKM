# Hints and Tips

## Setting QueryType and SearchMode

QueryType and SearchMode are unclear about it in the docs, but they are enums. So, you don't set them as `QueryType = "Full"`, but instead as `QueryType = QueryType.Full`

## Extracting data from skills

Be sure to set the Source Field mapping from outputs to start with "/document/content/" if that was the context you set, otherwise your indexer won't find solutions

Also, for skills that return lists, your output should end in "/*" so that it grabs all results.
