# Readme

## All Challenges

Be sure to update the appsettings.json for challenges 2 and 3!

Then, run `dotnet restore` and `dotnet build`, and finally `dotnet run`

## Challenge 1

The solution here for Challenge 1 is for testing your already created QnA Maker. The QnA Maker was provisioned via the Azure Portal.
