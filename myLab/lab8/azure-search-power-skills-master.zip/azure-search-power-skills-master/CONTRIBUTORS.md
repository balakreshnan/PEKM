# Contributors

This is the official list of Power Skills project contributors.
Some of the skills are derived from the [JFK Files project](https://github.com/microsoft/AzureSearch_JFK_Files)
and [Knowledge Mining Accelerator Guide](https://github.com/Azure-Samples/azure-search-knowledge-mining).
Contributors to those projects have been copied here.
Names of the original copyright holders (individuals or organizations)
should be listed with a '*' in the first column. People who have 
contributed from an organization can be listed under the organization
that actually holds the copyright for their contributions (see the 
Microsoft organization for an example). Those individuals should have
their names indented and be marked with a '-'
 
* Microsoft
  - Javier Calzado
  - Carey MacDonald
  - Corom Thompson
  - Luis Cabrera-Cordon
  - Liam Cavanagh
  - Christopher Romero
  - Bertrand Le Roy

* Lemoncode
  - Nasdan