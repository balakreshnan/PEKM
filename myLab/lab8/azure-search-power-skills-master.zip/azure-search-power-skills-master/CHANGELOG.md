# Azure Search Power Skills Changelog

<a name="0.0.1"></a>
## 0.0.1 (2019-06-12)

Project created

## 2019-06-17

GeoPointFromName and BingEntitySearch skills added.