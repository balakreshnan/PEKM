# Azure Search Index Restore

The purpose of this tool is to load contend into an Azure Search index.  In this sample, data for US Zip Codes as well as data from the NYC Jobs opendata dataset is used to create two indexes in Azure Search.  Please note, the data in the either datasets should not be considered up-to-date.